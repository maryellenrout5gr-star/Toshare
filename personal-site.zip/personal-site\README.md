# 邱良安 · 个人介绍网站

静态站点，无构建步骤、无外部依赖。四个文件即可部署。

## 文件清单

| 文件 | 作用 |
| --- | --- |
| `index.html` | 页面结构，所有内容已内联（部署即用） |
| `styles.css` | 工业蓝图主题样式 + CSS 动画 |
| `script.js` | 滚动动画、数字计数、导航高亮、手机号打码、邮箱复制 |
| `content.md` | 简历内容的 Markdown 源，便于编辑和搬运到其他平台 |
| `images/hero.jpg` | 首屏大图（165 KB）。**必须保持 `images/` 这个目录名**，否则图片 404 |

> ⚠️ 部署时记得连 `images/` 文件夹一起传，只传三个文本文件会导致首屏没有背景图。

## 本地预览

直接双击 `index.html` 就能看。如果想用本地服务器（推荐，行为和线上一致）：

```bash
# 任选一种
npx serve .
python -m http.server 8000
```

然后打开 http://localhost:8000

## 动画效果说明

- **首屏**：姓名逐字立体浮现，背景蓝图网格缓慢漂移，两枚齿轮反向旋转
- **滚动**：顶部进度条、各区块错峰淡入上移、技能标签依次弹入
- **数据区**：GPA / 经历 / 课程 / 证书 四个数字滚动到视口时从 0 计数
- **时间线**：竖线随滚动绘制，节点依次点亮
- **微交互**：鼠标轻微视差、导航当前区块高亮、手机号点击展开、邮箱一键复制

所有动画都遵守 `prefers-reduced-motion`：系统开了"减弱动效"时会自动关闭位移与计数动画，
内容照常完整显示。

## 部署到 Cloudflare Pages

### 方式一：直接上传（最快，不用 Git）

1. 打开 https://dash.cloudflare.com → **Workers & Pages** → **Create** → **Pages** → **Upload assets**
2. 给项目起名，例如 `qiuliangan`
3. 把 `index.html`、`styles.css`、`script.js` **和 `images` 整个文件夹**一起拖进去
   （`content.md`、`README.md` 不用上传）。目录结构要保持成：
   ```
   index.html
   styles.css
   script.js
   images/hero.jpg
   ```
4. 点 **Deploy site**，几十秒后拿到 `https://qiuliangan.pages.dev`

之后要更新：进项目 → **Deployments** → 重新上传改动的文件即可。

### 方式二：Wrangler CLI（适合以后频繁更新）

```bash
npm i -g wrangler
wrangler login
npx wrangler pages deploy . --project-name=qiuliangan
```

注意：这样会把当前目录所有文件都传上去，建议在部署前把 `README.md`、`content.md` 移走，
或者加一个 `.assetsignore` 文件排除它们。

### 方式三：连接 Git（适合长期维护）

1. 把这三个文件推到 GitHub 仓库
2. Cloudflare Pages → **Create** → **Connect to Git**
3. 构建配置留空即可（**Framework preset: None**，**Build command** 不填，
   **Build output directory** 填 `/`）
4. 之后每次 git push 自动重新部署

### 绑自己的域名

项目页 → **Custom domains** → **Set up a custom domain**，按提示加一条 CNAME 记录即可。
Cloudflare 会自动签发 HTTPS 证书。

## 修改内容

- 改文字：编辑 `index.html` 里对应的段落（`content.md` 是同步的内容源，改完记得两边一致）
- 改配色：编辑 `styles.css` 顶部的 `:root` 变量，改 `--accent`（安全橙）和 `--accent-2`（图纸蓝）就能整体换色
- 改动画节奏：`styles.css` 里的 `animation-delay`、`@keyframes` 时长；数字计数时长在 `script.js` 的 `duration`

### 技能熟练度是自评值

页面上的技能进度条（92 / 80 / 74 等）是我根据简历描述推断的**自评值**，不是简历原文里的数字。
在 `index.html` 里搜 `data-pct` 就能全部改掉，例如：

```html
<li><span class="bar-k">PLC 控制技术</span><span class="bar" data-pct="80"><i></i></span><span class="bar-v">80</span></li>
```

`data-pct` 和 `<span class="bar-v">` 里的数字改一致即可。如果你觉得写自评不严谨，
直接删掉整个 `<ul class="bars">`，保留标签列表也一样好看。

## 隐私提醒

页面上手机号默认是打码的（`183 **** 4086`），需要点一下"显示完整号码"才展开，
这是为了防止被爬虫批量抓取。如果这份站点只是发给特定公司看、不在意抓取，
可以把 `index.html` 里 `phoneMasked` 的内容直接写成完整号码，并删掉那个按钮。

邮箱是 `mailto:` 链接，点击会唤起邮件客户端 —— 这是爬虫常抓的目标，按需要保留。
