/* ==========================================================================
   邱良安 · 个人介绍页 — 交互脚本
   无依赖，原生 JS
   ========================================================================== */
(function () {
  'use strict';

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var PHONE_FULL = '18383824086';

  /* ---------- 滚动：进度条 + 导航渐变 ---------- */
  var bar = document.getElementById('progressBar');
  var head = document.getElementById('siteHead');
  var hero = document.getElementById('top');
  var ticking = false;

  function onScroll() {
    var doc = document.documentElement;
    var max = doc.scrollHeight - doc.clientHeight;
    if (bar) bar.style.width = (max > 0 ? (window.scrollY / max) * 100 : 0).toFixed(2) + '%';

    var threshold = hero ? hero.offsetHeight * 0.6 : 380;
    if (head) head.classList.toggle('is-solid', window.scrollY > threshold);

    ticking = false;
  }
  window.addEventListener('scroll', function () {
    if (!ticking) { ticking = true; window.requestAnimationFrame(onScroll); }
  }, { passive: true });
  window.addEventListener('resize', onScroll);
  onScroll();

  /* ---------- 移动端菜单 ---------- */
  var navToggle = document.getElementById('navToggle');
  var nav = document.querySelector('.nav');

  if (navToggle && nav) {
    navToggle.addEventListener('click', function () {
      var open = nav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      navToggle.setAttribute('aria-label', open ? '关闭导航菜单' : '打开导航菜单');
    });
    nav.addEventListener('click', function (e) {
      if (e.target.tagName === 'A') {
        nav.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  /* ---------- 入场动画 ---------- */
  var animEls = Array.prototype.slice.call(document.querySelectorAll('[data-anim]'));
  animEls.forEach(function (el) {
    var d = el.getAttribute('data-delay');
    if (d) el.style.setProperty('--d', parseInt(d, 10) + 'ms');
  });

  if ('IntersectionObserver' in window && !reduceMotion) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add('is-in'); io.unobserve(e.target); }
      });
    }, { threshold: 0.14, rootMargin: '0px 0px -6% 0px' });
    animEls.forEach(function (el) { io.observe(el); });
  } else {
    animEls.forEach(function (el) { el.classList.add('is-in'); });
  }

  /* ---------- 技能进度条 ---------- */
  var bars = Array.prototype.slice.call(document.querySelectorAll('.bar'));

  function fillBar(el) {
    var pct = parseFloat(el.getAttribute('data-pct') || '0');
    if (el.firstElementChild) el.firstElementChild.style.width = pct + '%';
  }

  if (bars.length) {
    if ('IntersectionObserver' in window) {
      var bio = new IntersectionObserver(function (entries) {
        entries.forEach(function (e) {
          if (e.isIntersecting) { fillBar(e.target); bio.unobserve(e.target); }
        });
      }, { threshold: 0.4 });
      bars.forEach(function (b) { bio.observe(b); });
    } else { bars.forEach(fillBar); }
  }

  /* ---------- 时间线 ---------- */
  var timeline = document.querySelector('.timeline');
  var jobs = Array.prototype.slice.call(document.querySelectorAll('.job'));

  if (timeline && jobs.length) {
    if ('IntersectionObserver' in window) {
      var tio = new IntersectionObserver(function (entries) {
        entries.forEach(function (e) {
          if (!e.isIntersecting) return;
          if (e.target === timeline) timeline.classList.add('is-drawn');
          else e.target.classList.add('is-in');
        });
      }, { threshold: 0.2 });
      tio.observe(timeline);
      jobs.forEach(function (j) { tio.observe(j); });
    } else {
      timeline.classList.add('is-drawn');
      jobs.forEach(function (j) { j.classList.add('is-in'); });
    }
  }

  /* ---------- 数字计数 ---------- */
  var counters = Array.prototype.slice.call(document.querySelectorAll('[data-count]'));

  function runCount(el) {
    var target = parseFloat(el.getAttribute('data-count'));
    var decimals = parseInt(el.getAttribute('data-decimals') || '0', 10);
    var suffix = el.getAttribute('data-suffix') || '';
    if (reduceMotion || !isFinite(target)) { el.textContent = target.toFixed(decimals) + suffix; return; }

    var duration = 1400, start = null;
    function step(ts) {
      if (start === null) start = ts;
      var p = Math.min((ts - start) / duration, 1);
      var eased = 1 - Math.pow(1 - p, 3);
      el.textContent = (target * eased).toFixed(decimals) + suffix;
      if (p < 1) window.requestAnimationFrame(step);
      else el.textContent = target.toFixed(decimals) + suffix;
    }
    window.requestAnimationFrame(step);
  }

  if (counters.length) {
    if ('IntersectionObserver' in window) {
      var cio = new IntersectionObserver(function (entries) {
        entries.forEach(function (e) {
          if (e.isIntersecting) { runCount(e.target); cio.unobserve(e.target); }
        });
      }, { threshold: 0.5 });
      counters.forEach(function (c) { cio.observe(c); });
    } else { counters.forEach(runCount); }
  }

  /* ---------- 导航当前区块高亮 ---------- */
  var navLinks = Array.prototype.slice.call(document.querySelectorAll('.nav a'));
  var sections = navLinks
    .map(function (a) { return document.querySelector(a.getAttribute('href')); })
    .filter(Boolean);

  if ('IntersectionObserver' in window && sections.length) {
    var sio = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) return;
        var id = '#' + e.target.id;
        navLinks.forEach(function (a) { a.classList.toggle('is-active', a.getAttribute('href') === id); });
      });
    }, { threshold: 0.1, rootMargin: '-42% 0px -50% 0px' });
    sections.forEach(function (s) { sio.observe(s); });
  }

  /* ---------- 手机号打码 / 显示 ---------- */
  var phoneMasked = document.getElementById('phoneMasked');
  var phoneToggle = document.getElementById('phoneToggle');
  var shown = false;

  if (phoneMasked && phoneToggle) {
    phoneToggle.addEventListener('click', function () {
      shown = !shown;
      phoneMasked.textContent = shown ? PHONE_FULL : '183 **** 4086';
      phoneToggle.textContent = shown ? '重新打码' : '显示完整号码';
      phoneToggle.setAttribute('aria-expanded', shown ? 'true' : 'false');
    });
  }

  /* ---------- 邮箱复制 ---------- */
  var copyBtn = document.getElementById('copyMail');
  var mail = '639796642@qq.com';

  if (copyBtn) {
    copyBtn.addEventListener('click', function () {
      var done = function () {
        var old = copyBtn.textContent;
        copyBtn.textContent = '已复制';
        setTimeout(function () { copyBtn.textContent = old; }, 1800);
      };
      function fallback() {
        var ta = document.createElement('textarea');
        ta.value = mail; ta.setAttribute('readonly', '');
        ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); done(); } catch (err) { /* ignore */ }
        document.body.removeChild(ta);
      }
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(mail).then(done, fallback);
      } else { fallback(); }
    });
  }

  /* ---------- Hero 图加载失败兜底 ---------- */
  var heroImg = document.getElementById('heroImg');
  if (heroImg) {
    heroImg.addEventListener('error', function () {
      heroImg.style.display = 'none';
    });
  }

})();
